# 网页

首先运行rasa服务器，开放5005端口并添加命令行参数--enable-api:
  python -m rasa run --enable-api

然后运行flask app.py，将开放5000端口:
  python app.py

就能从浏览器访问了:
  127.0.0.1:5000



星座图'static/zodiacs/*.svg'

